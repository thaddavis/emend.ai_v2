from langchain.schema import Document

__all__ = ["Document"]
